import React from 'react';
import SerieForm from '../components/SerieForm/SerieForm';

const CadastroPage = () => (
    <div style={{ padding: '20px' }}>
        <SerieForm />
    </div>
);
export default CadastroPage;