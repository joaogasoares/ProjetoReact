import React from 'react';
const HomePage = () => (
    <div style={{ padding: '20px', textAlign: 'center' }}>
        <h1>Bem-vindo ao Gerenciador de Séries!</h1>
        <p>Use a navegação acima para Cadastrar, Listar ou saber mais sobre o projeto.</p>
    </div>
);
export default HomePage;